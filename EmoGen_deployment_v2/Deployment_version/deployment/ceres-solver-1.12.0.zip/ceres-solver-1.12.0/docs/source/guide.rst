.. _chapter-users-guide:

============
User's Guide
============

.. toctree::
   :maxdepth: 2

   nnls_modeling
   nnls_solving
   gradient_solver
