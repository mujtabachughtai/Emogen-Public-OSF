Problem files are created from Tears of Steel production files.

- problem_01.bin is a final camera motion refinement step of 07_1a scene.
- problem_02.bin is a final camera motion refinement step of 03_2a scene.
- problem_03.bin is a final camera motion refinement step of 09_1a scene.
